#!/usr/bin/env python3

import datetime
import itertools
import os
import re
import sys

import attr
import backoff
import requests
import singer
from singer import utils

from glue_job_libs import general_utils as gu
from glue_job_libs import s3_util as s3
from appsflyer.job_config import JobConfig




LOGGER = singer.get_logger()
SESSION = requests.Session()


CONFIG = {
    "app_id": None,
    "api_token": None,
}


STATE = {}


ENDPOINTS = {
    "installs": "/export/{app_id}/installs_report/v5",
    "installs_retargeting": "/export/{app_id}/installs_report/v5",
    "organic_installs": "/export/{app_id}/organic_installs_report/v5",
    "in_app_events": "/export/{app_id}/in_app_events_report/v5",
    "in_app_events_retargeting": "/export/{app_id}/in_app_events_report/v5",
    "organic_in_app_events": "/export/{app_id}/organic_in_app_events_report/v5"
}

EXTRA_ENDPOINT_PARAMETERS = {
    "installs": False,
    "installs_retargeting": True,
    "organic_installs": False,
    "in_app_events": False,
    "in_app_events_retargeting": True,
    "organic_in_app_events": False
}

s3_client = s3.AWSS3()



def af_datetime_str_to_datetime(s):
    return datetime.datetime.strptime(s.strip(), "%Y-%m-%d %H:%M:%S")

def date_trunc(dt):
    return dt.replace(hour=0, minute=0, second=0, microsecond=0)

def get_start(app_id, report_type):
    if report_type in STATE["bookmarks"].get(app_id):
        return utils.strptime(STATE["bookmarks"][app_id][report_type])

    if "start_date" in CONFIG:
        return utils.strptime(CONFIG["start_date"])

    return datetime.datetime.now() - datetime.timedelta(days=30)


def get_stop(start_datetime, stop_time, days=30):
    return min(start_datetime + datetime.timedelta(days=days), stop_time)


def get_base_url():
    if "base_url" in CONFIG:
        return CONFIG["base_url"]
    else:
        return "https://hq.appsflyer.com"


def get_url(endpoint, **kwargs):
    if endpoint not in ENDPOINTS:
        raise ValueError("Invalid endpoint {}".format(endpoint))
    else:
        return get_base_url() + ENDPOINTS[endpoint].format(**kwargs)

def get_retargeting_parameter(endpoint):
    if endpoint not in EXTRA_ENDPOINT_PARAMETERS:
        raise ValueError("Invalid endpoint {}".format(endpoint))
    else:
        return EXTRA_ENDPOINT_PARAMETERS[endpoint]


@attr.s
class Stream(object):
    name = attr.ib()
    sync = attr.ib()


def get_abs_path(path):
    return os.path.join(os.path.dirname(os.path.realpath(__file__)), path)


def update_state_file(state):
    s3_client.upload_json_to_s3(bucket=CONFIG["job_config_bucket"], json_object=state, file_name_in_bucket=CONFIG["state_file_path"])

def load_schema(entity_name):
    schema = utils.load_json(get_abs_path('schemas/{}.json'.format(entity_name)))
    return schema


def giveup(exc):
    return exc.response is not None and 400 <= exc.response.status_code < 500


def parse_source_from_url(url):
    url_regex = re.compile(get_base_url() + r'.*/(\w+)_report/v5')
    match = url_regex.match(url)
    if match:
        return match.group(1)
    return None


def get_csv_file_name(from_date, to_date, stream_name):
    salt = datetime.datetime.now().strftime('%Y%m%d%H%M%S%f')
    export_file = 'landing/{}/{}{}_{}_{}_{}.csv'.format(stream_name, gu.get_partition_name_by_date(datetime.datetime.now()), stream_name, from_date, to_date, salt)
    output_dir = os.path.dirname(export_file)
    if not os.path.exists(get_abs_path(output_dir)) and output_dir != '':
        os.makedirs(get_abs_path(output_dir))
    return export_file


@backoff.on_exception(backoff.expo,
                      (requests.exceptions.RequestException),
                      max_tries=5,
                      giveup=giveup,
                      factor=2)
@utils.ratelimit(10, 1)
def request(url, params=None):

    params = params or {}
    headers = {}

    if "user_agent" in CONFIG:
        headers["User-Agent"] = CONFIG["user_agent"]

    req = requests.Request("GET", url, params=params, headers=headers).prepare()
    LOGGER.info("GET %s", req.url)

    with singer.metrics.http_request_timer(endpoint=parse_source_from_url(url)) as stats:
        resp = SESSION.send(req)

    if resp.status_code >= 400:
        LOGGER.error("GET %s [%s - %s]", req.url, resp.status_code, resp.content)
        sys.exit(1)

    return resp


class RequestToCsvAdapter:
    def __init__(self, request_data):
        self.request_data_iter = request_data.iter_lines();

    def __iter__(self):
        return self

    def __next__(self):
        return next(self.request_data_iter).decode("utf-8")


def sync_installs(stream):
    stop_time = date_trunc(datetime.datetime.now())
    from_datetime = get_start(CONFIG['app_id'], stream)
    to_datetime = date_trunc(get_stop(from_datetime, stop_time, 10))

    while from_datetime < stop_time:

        if to_datetime < from_datetime:
            LOGGER.error("to_datetime (%s) is less than from_endtime (%s).", to_datetime, from_datetime)
            return

        params = dict()
        params["from"] = from_datetime.strftime("%Y-%m-%d %H:%M")
        params["to"] = to_datetime.strftime("%Y-%m-%d %H:%M")
        params["api_token"] = CONFIG["api_token"]
        params["reattr"] = get_retargeting_parameter(endpoint=stream)

        url = get_url(stream, app_id=CONFIG["app_id"])
        request_data = request(url, params)

        output_csv_file = get_csv_file_name(
            from_datetime.strftime("%Y%m%d%H%M"),
            to_datetime.strftime("%Y%m%d%H%M"),
            stream
        )
        with open(get_abs_path(output_csv_file), 'wb') as f:
            f.write(request_data.content)

        s3_client.upload_file_to_s3(CONFIG["destination_bucket"], get_abs_path(output_csv_file), output_csv_file)

        bookmark = datetime.datetime.strftime(to_datetime, utils.DATETIME_PARSE)

        # Write out state
        utils.update_state(STATE['bookmarks'][CONFIG['app_id']], stream, bookmark)
        update_state_file(STATE)

        # Move the timings forward
        from_datetime = to_datetime
        to_datetime = get_stop(from_datetime, stop_time, 10)


def sync_in_app_events(stream):

    stop_time = date_trunc(datetime.datetime.now())
    from_datetime = get_start(CONFIG['app_id'], stream)
    to_datetime = date_trunc(get_stop(from_datetime, stop_time, 10))

    while from_datetime < stop_time:
        LOGGER.info("Syncing data from %s to %s", from_datetime, to_datetime)
        params = dict()
        params["from"] = from_datetime.strftime("%Y-%m-%d %H:%M")
        params["to"] = to_datetime.strftime("%Y-%m-%d %H:%M")
        params["api_token"] = CONFIG["api_token"]
        params["reattr"] = get_retargeting_parameter(endpoint=stream)

        url = get_url(stream, app_id=CONFIG["app_id"])
        request_data = request(url, params)

        output_csv_file = get_csv_file_name(
            from_datetime.strftime("%Y%m%d%H%M"),
            to_datetime.strftime("%Y%m%d%H%M"),
            stream
        )

        with open(get_abs_path(output_csv_file), 'wb') as f:
            f.write(request_data.content)

        s3_client.upload_file_to_s3(CONFIG["destination_bucket"], get_abs_path(output_csv_file), output_csv_file)

        # Write out state
        bookmark = datetime.datetime.strftime(to_datetime, utils.DATETIME_PARSE)
        utils.update_state(STATE['bookmarks'][CONFIG['app_id']], stream, bookmark)
        update_state_file(STATE)

        # Move the timings forward
        from_datetime = to_datetime
        to_datetime = get_stop(from_datetime, stop_time, 10)


STREAMS = [
    Stream("installs", sync_installs),
    Stream("installs_retargeting", sync_installs),
    Stream("in_app_events", sync_in_app_events),
    Stream("in_app_events_retargeting", sync_in_app_events),
    Stream("organic_installs", sync_installs),
    Stream("organic_in_app_events", sync_in_app_events)
]

# STREAMS = [
#     Stream("installs_retargeting", sync_installs),
#     Stream("in_app_events_retargeting", sync_in_app_events)
# ]

def get_streams_to_sync(streams, state):
    target_stream = state.get("this_stream")
    result = streams
    if target_stream:
        result = list(itertools.dropwhile(lambda x: x.name != target_stream, streams))
    if not result:
        raise Exception('Unknown stream {} in state'.format(target_stream))
    return result


def do_sync():
    LOGGER.info("Starting sync...")
    LOGGER.info("STATE:{}".format(STATE))
    streams = get_streams_to_sync(STREAMS, STATE)
    LOGGER.info('Starting sync. Will sync these streams: %s', [stream.name for stream in streams])
    for stream in streams:
        LOGGER.info('Syncing %s', stream.name)
        stream.sync(stream.name) # pylint: disable=not-callable
    singer.write_state(STATE)
    LOGGER.info("Sync completed")


def run(job_config:JobConfig, state):

    all_apps = [
        'com.transfergo.android',
        'id1110641576'
    ]

    STATE.update(state.state)


    CONFIG["api_token"] = job_config.get_access_token()
    CONFIG["destination_bucket"] = job_config.job_output_bucket
    CONFIG["state_file_path"] = job_config.job_state_file
    CONFIG["job_config_bucket"] = job_config.glue_bucket


    for app in all_apps:
        CONFIG["app_id"] = app
        do_sync()


