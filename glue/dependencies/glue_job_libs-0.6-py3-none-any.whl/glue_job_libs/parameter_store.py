import boto3


class ParameterStore:

    def get_encrypted_parameter_value(self, parameter_name: str, decrypt: bool = True) -> str:
        self.ssm_client = boto3.client('ssm')
        return self.ssm_client.get_parameter(Name=parameter_name, WithDecryption=decrypt)['Parameter']['Value']


