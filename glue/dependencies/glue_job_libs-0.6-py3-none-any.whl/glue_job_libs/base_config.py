from glue_job_libs import s3_util
import argparse
import json
import os


class BaseConfig:
    def __init__(self):
        parser = argparse.ArgumentParser()
        parser.add_argument("-e", "--environment", choices=['STAGING', 'PRODUCTION'],
                            help="Available values: STAGING, PRODUCTION")
        parser.add_argument("-d", "--data_source")
        parser.add_argument("-j", "--job_type")
        args, unknown_args = parser.parse_known_args()

        self._environment = self.check_mandatory_args('environment', args.environment)
        self._data_source = self.check_mandatory_args('data_source', args.data_source)
        self._job_type = args.job_type
        self._glue_bucket = 'aws-glue-scripts-082806765249-eu-west-1'

    @staticmethod
    def check_mandatory_args(arg_name, arg_value):
        if arg_value is None:
            raise Exception(f"{arg_name} argument is None")

        return arg_value

    @property
    def environment(self):
        return self._environment

    @property
    def glue_bucket(self):
        return self._glue_bucket

    @property
    def data_source(self):
        return self._data_source

    @property
    def job_type(self):
        return self._job_type

    @property
    def job_output_bucket(self):
        return f'tgo-{self.data_source}-{str(self.environment).lower()}'

    @property
    def job_config_file(self):
        folder = f'{self.environment}-{self.data_source}'

        if self.job_type != '':
            result = os.path.join(folder, self.job_type,  'config',  'config.json')

        else:
            result = os.path.join(folder, 'config', 'config.json')

        return result

    @property
    def job_state_file(self):
        folder = f'{self.environment}-{self.data_source}'

        if self.job_type != '':
            result = os.path.join(folder, self.job_type,  'config', 'state.json')

        else:
            result = os.path.join(folder, 'config', 'state.json')

        return result

    @property
    def job_catalog_file(self):
        folder = f'{self.environment}-{self.data_source}'

        if self.job_type != '':
            result = os.path.join(folder, self.job_type,  'config', 'catalog.json')

        else:
            result = os.path.join(folder, 'config', 'catalog.json')

        return result

    def get_job_config_json(self):
        s3 = s3_util.AWSS3()
        file_object = s3.get_s3_file(bucket=self.glue_bucket, file=self.job_config_file)
        job_config_json = json.loads(file_object)

        return job_config_json




