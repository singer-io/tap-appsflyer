import boto3
from boto3.dynamodb.conditions import Key
import datetime


class DynamoDBDatabase:
    def __init__(self):
        self.dynamodb_client = boto3.client('dynamodb')
        self.dynamodb = boto3.resource('dynamodb')

    def get_table(self, table_name):
        table = self.dynamodb.Table(table_name)
        return table

    def add_record_to_table(self, table_name, record):
        table = self.get_table(table_name)
        response = table.put_item(
            Item=record
        )
        return response

    def add_item(self, table_name, record):
        table = self.get_table(table_name)
        response = table.put_item(
            Item=record
        )
        return response

    def update_item(self, table_name, record):
        table = self.get_table(table_name)
        response = table.put_item(
            Item=record
        )
        return response

    def delete_item(self, table_name, record):
        table = self.get_table(table_name)
        response = table.delete_item(
            Key={
                'pk': record["pk"],
                'sk': record["sk"]
            }
        )
        return response

    def get_unprocessed_records(self, table_name, bucket):
        pk = "bucket:{}#status:landed#version:active".format(bucket)
        table = self.get_table(table_name)
        records = table.query(
            KeyConditionExpression=Key('pk').eq(pk)
        )
        return records["Items"]

    def get_items_by_gsi(self, table_name, bucket, file_key):
        pk = bucket
        sk = file_key
        table = self.get_table(table_name)
        records = table.query(
            IndexName='bucket-file_key-index',
            KeyConditionExpression=Key('bucket').eq(pk) & Key('file_key').begins_with(sk)
        )
        return records["Items"]

    def get_raw_files_to_transform(self, table_name, bucket):
        pk = "bucket:{}#status:transform#version:active".format(bucket)
        table = self.get_table(table_name)
        records = table.query(
            KeyConditionExpression=Key('pk').eq(pk)
        )
        return records["Items"]


    @staticmethod
    def get_unprocessed_files(records):
        list_of_files = []
        for row in records:
            #list_of_files.append('s3://{}/{}'.format(row["data_source"], row["file_key"]))
            list_of_files.append(row["file_key"])
        return list_of_files

    @staticmethod
    def get_unprocessed_file(records):
        return records["file_key"]

    def change_status_from_landed_to_transform(self, table_name, old_record, new_file_key):
        new_status_record = {
            "pk": old_record["pk"].replace("#status:landed", "#status:transformed"),
            "sk": old_record["sk"],
            "status": old_record["status"],
            "bucket": old_record["bucket"],
            "file_key": old_record["file_key"],
            "status_dt": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"),
            "process_key": old_record["process_key"],
            "modified_at": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"),
            "new_file_key": new_file_key
        }
        audit_record = {
            "pk": old_record["pk"].replace("#version:active", "#version:audit"),
            "sk": old_record["sk"],
            "bucket": old_record["bucket"],
            "file_key": old_record["file_key"],
            "status": "transformed",
            "status_dt": old_record["status_dt"],
            "process_key": old_record["process_key"],
            "modified_at": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
        }
        response = self.add_item(table_name=table_name, record=new_status_record)
        response = self.add_item(table_name=table_name, record=audit_record)
        response = self.delete_item(table_name=table_name, record=old_record)
        return response

    def change_log_record_version_to_audit(self, table_name, old_record):
        audit_record = {
            "pk": old_record["pk"].replace("#version:active", "#version:audit"),
            "sk": old_record["sk"],
            "bucket": old_record["bucket"],
            "file_key": old_record["file_key"],
            "status": old_record["status"],
            "status_dt": old_record["status_dt"],
            "process_key": old_record["process_key"],
            "modified_at": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
        }
        response = self.add_item(table_name=table_name, record=audit_record)
        response = self.delete_item(table_name=table_name, record=old_record)
        return response

    def change_log_record_version_to_active(self, table_name, old_record):
        active_record = {
            "pk": old_record["pk"].replace("#version:audit", "#version:active"),
            "sk": old_record["sk"],
            "bucket": old_record["bucket"],
            "file_key": old_record["file_key"],
            "status": old_record["status"],
            "status_dt": old_record["status_dt"],
            "process_key": old_record["process_key"],
            "modified_at": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
        }
        response = self.add_item(table_name=table_name, record=active_record)
        response = self.delete_item(table_name=table_name, record=old_record)
        return response

    def add_unprocessed_transform_row(self, table_name, bucket, file_key):
        status_timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
        new_status_record = {
            "pk": "bucket:{}#status:transformed#version:active".format(bucket),
            "sk": "dt:{}#file_key:{}".format(status_timestamp, file_key),
            "status": "transformed",
            "bucket": bucket,
            "file_key": file_key,
            "status_dt": status_timestamp,
            "process_key": "",
            "modified_at": status_timestamp
        }
        response = self.add_item(table_name=table_name, record=new_status_record)
        return response

    @staticmethod
    def get_landed_active_pk(bucket):
        pk = "bucket:{}#status:landed#version:active".format(bucket)
        return pk

    # def get_all_items_for_pk(self, table_name, pk):
    #     results = []
    #     paginator = self.dynamodb_client.get_paginator('query')
    #
    #     operation_parameters = {
    #         'TableName': table_name,
    #         'KeyConditionExpression': 'pk = :x',
    #         'ExpressionAttributeValues': {
    #             ':x': {'S': pk}
    #         }
    #     }
    #
    #     page_iterator = paginator.paginate(**operation_parameters)
    #
    #     for i, page in enumerate(page_iterator):
    #         print("page: {}".format(i))
    #         results.append(page["Items"])
    #         if i == 1:
    #             break
    #
    #     return results

    def get_all_items_for_pk(self, table_name, pk):
        results = []
        i = 0
        table = self.get_table(table_name)
        response = table.query(
            KeyConditionExpression=Key('pk').eq(pk),
            ReturnConsumedCapacity="TOTAL"
        )
        results = response['Items']

        while response.get('LastEvaluatedKey', False):
            response = table.query(
                ExclusiveStartKey=response['LastEvaluatedKey'],
                KeyConditionExpression=Key('pk').eq(pk)
            )
            results.extend(response['Items'])
            i = i+1
            if i == 0:
                break


        return results





