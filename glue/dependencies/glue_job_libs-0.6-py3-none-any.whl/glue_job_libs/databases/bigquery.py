from google.cloud import bigquery
import json
from google.oauth2 import service_account
import pandas


class BigQueryClient:
    def __init__(self, credentials_json):

        json_account_info = json.loads(credentials_json)  # convert JSON to dictionary
        credentials = service_account.Credentials.from_service_account_info(
            json_account_info)

        self.client = bigquery.Client(credentials=credentials)

    def run_query(self, sql):
        query_job = self.client.query(sql)
        results = query_job.result()
        return results

    def run_query_to_dataframe(self, sql):
        results_df = self.client.query(sql).to_dataframe()
        return results_df

