import csv
import pymysql


class MySQLDatabase:
    def __init__(self, host, port, db, user, password):
        self.conn = pymysql.connect(host=host, port=port, db=db, user=user, password=password, cursorclass=pymysql.cursors.SSCursor)
        self.cursor = self.conn.cursor()
        print("Connection established successfully")

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.cursor.close()
        self.conn.close()

    def run_query(self, sql):
        self.cursor.execute(sql)
        results = self.cursor.fetchall()
        return results

    def run_select_to_file(self, sql, file):
        self.cursor.execute(sql)
        header = self.cursor.description
        with open(file, "w") as outfile:
            writer = csv.writer(outfile, quoting=csv.QUOTE_NONNUMERIC)
            writer.writerow(col[0] for col in header)
            num_of_row = 0
            while True:
                row = self.cursor.fetchone()
                if row == None:
                    break
                writer.writerow(row)
                num_of_row = num_of_row + 1

        print('{} rows exported to file: {}'.format(num_of_row, file))
