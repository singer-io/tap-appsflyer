import csv
import redshift_connector


class RedshiftDatabase:
    def __init__(self, host, port, db, user, password):
        self.conn = redshift_connector.connect(host=host, port=port, database='dms', user=user, password=password)
        self.conn.autocommit = True
        self.cursor: redshift_connector.Cursor = self.conn.cursor()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.cursor.close()
        self.conn.close()

    def run_query(self, sql):
        self.cursor.execute(sql)
        results: tuple = self.cursor.fetchall()
        return results

    def run_dml_query(self, sql):
        #self.cursor.execute('begin;')
        self.cursor.execute(sql)
        #self.cursor.execute('commit;')

        # results = self.cursor.fetchall()
        #results = self.conn.query(sql)


        return 'DONE'


    def get_etl_process_status_by_id(self):
        sql = """
            select
                   case
                        when  completed.completed_cnt = 1 or running.running_cnt = 0
                        then true
                        else false
                    end as can_start
            
            from
                 (
                    select cast(count(1) as int) as completed_cnt
                    from admin.etl_load_process
                    where process_id = '' and step_name = 'Completed successfully'
                ) as completed,
                 (
                    select cast(count(1) as int) as running_cnt
                    from admin.etl_load_process
                    where process_id = '' and isnull(step_name, '-') <> 'Completed successfully'
                ) as running"""
        result = self.run_query(sql)
        return result

    def run_select_to_file(self, sql, file):
        rows = self.conn.execute(sql)

        with open(file, "w") as outfile:
            writer = csv.writer(outfile, quoting=csv.QUOTE_NONNUMERIC)
            for row in rows:
                writer.writerow(row)
        print('{} rows exported to file: {}'.format(len(rows), file))
