import json
import os
import datetime
import csv

def add_timestamp_to_file_name(file_name, timestamp=datetime.datetime.now()):
    base_file_name = os.path.splitext(file_name)[0]
    file_extension = os.path.splitext(file_name)[1]
    new_file = "{0}_{1}{2}".format(base_file_name, int(timestamp.strftime('%Y%m%d%H%M%S%f')), file_extension)
    create_dir_if_not_exists(new_file)
    return new_file


def create_dir_if_not_exists(file_path):
    output_dir = os.path.dirname(file_path)
    if not os.path.exists(output_dir) and output_dir != '':
        os.makedirs(output_dir)


def build_manifest_file_content(bucket, files):
    manifest_lines = []
    for file in files:
        full_file_path = "s3://{}/{}".format(bucket, file)
        manifest_lines.append({"url": full_file_path, "mandatory": True})
    manifest_content = {"entries": manifest_lines}
    return manifest_content


def write_to_json_file(output_file_path, file_content):
    with open(output_file_path, 'w') as fp:
        json.dump(file_content, fp)
    return output_file_path


def read_file(file_path):
    with open(file_path) as json_file:
        data = json_file.read()
    return data


def get_partition_name_by_date(timestamp):
    year = timestamp.strftime('%Y')
    month = timestamp.strftime('%Y%m')
    day = timestamp.strftime('%Y%m%d')
    return '{}/{}/{}/'.format(year, month, day)


def add_partition_info_to_file_key(partition, file_key):
    base_file_name = os.path.basename(file_key)
    directory = os.path.dirname(file_key)
    new_file = "{0}/{1}{2}".format(directory, partition, base_file_name)
    return new_file


def flush_df_to_parquet(df, output_file, compression='gzip'):
    if compression == "gzip":
        output_file = output_file
    df.to_parquet(output_file, index=None)
    return output_file


def is_buffer_full(buffer_size, current_buffer_size):
    if current_buffer_size > buffer_size:
        return True
    else:
        return False


def write_to_csv_file(output_file_path, file_rows, file_header=None):

    with open(output_file_path, 'w', encoding='UTF8') as f:
        writer = csv.writer(f)

        # write the header
        if file_header:
            writer.writerow(file_header)

        # write multiple rows
        writer.writerows(file_rows)

    return output_file_path
