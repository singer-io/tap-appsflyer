import json
from glue_job_libs import general_utils, s3_util


class State:
    def __init__(self,
                 state_file_bucket: str,
                 state_file_key: str
                 ):

        self.s3_client = s3_util.AWSS3()
        self.state_file_key = state_file_key
        self.state_file_bucket = state_file_bucket
        self.state = self._read_state_file()

    def _read_state_file(self):
        state = json.loads(self.s3_client.get_s3_file(bucket=self.state_file_bucket, file=self.state_file_key))
        return state

    def persist_bookmark_to_file(self):

        general_utils.create_dir_if_not_exists(self.state_file_key)

        with open(self.state_file_key, 'w') as outfile:
            json.dump(self.state, outfile)

        self.s3_client.upload_file_to_s3(
            bucket=self.state_file_bucket,
            file_to_upload=self.state_file_key,
            file_name_in_bucket=self.state_file_key
        )

    def get_bookmark(self, report_name) -> str:
        return self.state['bookmarks'][report_name]

    def set_bookmark(self, report_name, new_bookmark):
        self.state['bookmarks'][report_name] = new_bookmark
