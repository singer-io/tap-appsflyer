import sys
from glue_job_libs.databases import dynamodb

from glue_job_libs import glue_util
from glue_job_libs import general_utils as gu
from glue_job_libs import s3_util
import importlib
import logging
import os
import re
import datetime
import pyarrow as pa
import pyarrow.parquet as pq
import pandas as pd
import inspect
import gzip
import time

DYNAMODB_TABLE_NAME = "s3_log"
root = logging.getLogger()
root.setLevel(logging.INFO)

root = logging.getLogger()
root.setLevel(logging.INFO)


handler = logging.StreamHandler(sys.stdout)
handler.setLevel(logging.INFO)
formatter = logging.Formatter('%(levelname)s - %(message)s')
handler.setFormatter(formatter)
root.addHandler(handler)
root.info("check")


# def dynamic_import(package_name, class_name):
#
#     root.info("loading {} module.".format(package_name))
#
#     module = importlib.import_module('{}'.format(package_name))
#     for x in dir(module):
#         if x == class_name:
#             dynamic_class = getattr(module, x)
#             if inspect.isclass(dynamic_class):
#                 return dynamic_class
#
#     return dynamic_class


def add_extra_columns(df, s3_partition_column_name, raw_file_key_column_name, raw_file_key):
    """
    Add partition column and raw file name.
    Partition column will be used in other steps to create s3 file key with partition info
    and will not be saved in the output file.
    Raw file name will be kept in the output file.
    This will be useful when you need to find raw file of the records in the output file.
    """
    try:
        df[s3_partition_column_name] = df["partition_key_dt"].apply(
            lambda x: gu.get_partition_name_by_date(
                datetime.datetime.strptime(x[:19], '%Y-%m-%dT%H:%M:%S')))
        df[raw_file_key_column_name] = raw_file_key
    except KeyError as e:
        print(e)
        print('DataFrame from file {} has issu'.format(raw_file_key))
        print(df.head(1))
        raise
    return df


def main(config, parser_class_map):

    s3_client = s3_util.AWSS3()

    for step in config.transform_steps:

        if step.step_type == "landing_to_transform":
            dynamo_db = dynamodb.DynamoDBDatabase()
            s3_partition_column_name = "s3_partition"
            raw_file_key_column_name = "raw_file_key"

            output_file_key = step.output_file_key_template
            output_bucket = config.job_output_bucket
            buffer_size = step.buffer_size
            rows_in_buffer_limit = step.rows_in_buffer_limit
            data_bucket = config.job_output_bucket
            parser_package = step.parser_package
            parser_class = step.parser_class
            raw_file_regex = step.raw_file_regex
            add_timestamp_to_output_file = step.add_timestamp_to_output_file

            aws_glue_client = glue_util.AWSGlue()
            pk = dynamo_db.get_landed_active_pk(bucket=data_bucket)

            raw_files_to_transform = dynamo_db.get_all_items_for_pk(table_name=DYNAMODB_TABLE_NAME, pk=pk)

            raw_files_to_transform_filtered = []
            if raw_file_regex:
                matcher = re.compile(raw_file_regex)
                for row in raw_files_to_transform:
                    if bool(re.search(raw_file_regex,row['file_key'])) == True:
                        raw_files_to_transform_filtered.append(row)
                raw_files_to_transform = raw_files_to_transform_filtered


            #ParserClass = dynamic_import(package_name=parser_package, class_name=parser_class)

            parser = parser_class_map[step.parser_class]()

            root.info("Total number of files to process: {}".format(len(raw_files_to_transform)))

            raw_files_to_transform_in_buffer = []
            parsed_records = {}
            for i, row in enumerate(raw_files_to_transform):
                raw_files_to_transform_in_buffer.append(row)
                raw_file_key = dynamo_db.get_unprocessed_file(raw_files_to_transform[i])
                root.info("Processing file: {}. {}".format(i, raw_file_key))

                if raw_file_key.split('.')[-1] == 'gz':
                    file = s3_client.get_s3_file_v2(bucket=data_bucket, file=raw_file_key)
                    with gzip.open(file['Body'], 'rb') as gz_content:
                        file_content = gz_content.read().decode("utf-8")

                elif raw_file_key.split('.')[-1] == 'csv':
                    file_content = s3_client.get_s3_file_v2(bucket=data_bucket, file=raw_file_key)

                else:
                    file_content = s3_client.get_s3_file(bucket=data_bucket, file=raw_file_key)

                root.info("Server memory status after file read: {}".format(aws_glue_client.get_memory_usage()))

                tables_list, is_parsed = parser.parse_raw_data(file_content, raw_file_key)

                # free up memory
                file_content = ''
                to_much_rows_in_buffer = False
                for table, table_info in tables_list.items():
                    if table_info["df"].shape[0] > 0:

                        df = add_extra_columns(
                            df=table_info["df"],
                            s3_partition_column_name=s3_partition_column_name,
                            raw_file_key_column_name=raw_file_key_column_name,
                            raw_file_key=raw_file_key
                        )

                        # Check if this is first time when the table was generated.
                        # If this is first time then it needs to create new entry.
                        # If not first time, then just make append to the old table.
                        if parsed_records.get(table):
                            parsed_records[table]["df"] = pd.concat([parsed_records[table]["df"], df])
                        else:
                            parsed_records.update({table: {"df": df}})

                        # free up memory
                        df = []

                        root.info("Rows in DataFrame: {}".format(parsed_records[table]["df"].shape[0]))
                        root.info("Server memory status after DataFrame was added to 'parsed_records': {}".format(aws_glue_client.get_memory_usage()))

                        if rows_in_buffer_limit:
                            to_much_rows_in_buffer = True if parsed_records[table]["df"].shape[0] > rows_in_buffer_limit else False

                # Check if the number of rows is more than buffer size or the file is the last one to process.
                if gu.is_buffer_full(buffer_size, len(raw_files_to_transform_in_buffer)) \
                        or (len(raw_files_to_transform) - 1) == i or to_much_rows_in_buffer:

                    for table_name, table_info in parsed_records.items():
                        parsed_records_df = table_info["df"]

                        # One raw file can have more than one partition. So collect distinct partitions.
                        partitions = parsed_records_df[s3_partition_column_name].unique()
                        raw_files = []

                        # creating output files for each partition.
                        # One partitions can have more than one output file.
                        for partition in partitions:
                            partition_data = parsed_records_df[parsed_records_df[s3_partition_column_name] == partition]

                            # Partition column is not needed in the output file. So remove it.
                            partition_data = partition_data.drop([s3_partition_column_name, "partition_key_dt"], axis=1)

                            # Prepare output file key
                            output_file = output_file_key.format(table_name=table_name)
                            datetime_now = datetime.datetime.now()
                            output_file = gu.add_partition_info_to_file_key(partition, output_file)
                            if add_timestamp_to_output_file:
                                output_file = gu.add_timestamp_to_file_name(output_file, datetime_now)
                            gu.create_dir_if_not_exists(output_file)

                            root.info("Creating file: {}".format(output_file))

                            parquet_fields = []
                            for column in partition_data.columns:
                                parquet_fields.append(pa.field(column, pa.string()))
                            parquet_schema = pa.schema(parquet_fields)
                            table = pa.Table.from_pandas(partition_data, schema=parquet_schema, preserve_index=False)
                            pq.write_table(table, output_file, coerce_timestamps='ms')
                            root.info("File created: {}".format(output_file))

                            table = []
                            partition_data = []

                            s3_client.upload_file_to_s3(output_bucket, output_file, output_file)
                            root.info("File sent to S3: {}".format(output_file))

                            # create log record after the "transformed" file has been created
                            dynamo_db.add_unprocessed_transform_row(
                                table_name=DYNAMODB_TABLE_NAME,
                                bucket=data_bucket,
                                file_key=output_file
                            )
                            os.remove(output_file)

                    # Create log records in DynamoDB
                    root.info("Register {} processed files in DynamoDB.".format(len(raw_files_to_transform_in_buffer)))
                    for raw_file_to_transform_in_buffer in raw_files_to_transform_in_buffer:
                        dynamo_db.change_log_record_version_to_audit(
                            table_name=DYNAMODB_TABLE_NAME,
                            old_record=raw_file_to_transform_in_buffer
                        )
                    # clean variables
                    raw_files_to_transform_in_buffer = []
                    parsed_records = {}
                    table_info = []









