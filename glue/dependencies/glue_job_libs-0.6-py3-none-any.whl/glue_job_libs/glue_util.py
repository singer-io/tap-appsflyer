import collections
import shutil
import os
import boto3



class AWSGlue:
    def __init__(self, region='eu-west-1'):
        self.client = boto3.client('glue', region_name=region)

    def get_glue_connection_info(self, connection_name):
        connection_info = collections.namedtuple('connection_info', 'host, port, database, user, pwd')

        response = self.client.get_connection(Name=connection_name)

        connection_properties = response['Connection']['ConnectionProperties']
        url = connection_properties['JDBC_CONNECTION_URL']
        url_list = url.split("/")

        host = "{}".format(url_list[-2][:-5])
        port = url_list[-2][-4:]
        database = "{}".format(url_list[-1])
        user = "{}".format(connection_properties['USERNAME'])
        pwd = "{}".format(connection_properties['PASSWORD'])

        results = connection_info(host, int(port), database, user, pwd)

        return results

    @staticmethod
    def get_disc_info(disc="/"):
        disk_info = collections.namedtuple('disk_info', 'total_space, used_space, free_space')
        total, used, free = shutil.disk_usage(disc)
        results = disk_info(total, used, free)
        # print("Total: %d GiB" % (disc_info.total_space // (2 ** 30)))
        # print("Used: %d GiB" % (disc_info.used_space // (2 ** 30)))
        # print("Free: %d GiB" % (disc_info.free_space // (2 ** 30)))

        return results

    @staticmethod
    def get_memory_usage():
        memory_info = collections.namedtuple('memory_info', 'total_memory, free_memory')
        with open('/proc/meminfo') as file:
            for line in file:
                if 'MemTotal' in line:
                    total_mem_in_kb = line.split()[1]

                if 'MemFree' in line:
                    free_mem_in_kb = line.split()[1]
        results = memory_info(total_mem_in_kb, free_mem_in_kb)
        return results

    @staticmethod
    def get_current_directory():
        return os.getcwd()


class GlueServer:
    @staticmethod
    def get_disc_info(disc="/"):
        disk_info = collections.namedtuple('disk_info', 'total_space, used_space, free_space')
        total, used, free = shutil.disk_usage(disc)
        results = disk_info(total, used, free)
        # print("Total: %d GiB" % (disc_info.total_space // (2 ** 30)))
        # print("Used: %d GiB" % (disc_info.used_space // (2 ** 30)))
        # print("Free: %d GiB" % (disc_info.free_space // (2 ** 30)))

        return results

    @staticmethod
    def get_memory_usage():
        memory_info = collections.namedtuple('memory_info', 'total_memory, free_memory')
        with open('/proc/meminfo') as file:
            for line in file:
                if 'MemTotal' in line:
                    total_mem_in_kb = line.split()[1]

                if 'MemFree' in line:
                    free_mem_in_kb = line.split()[1]
        results = memory_info(total_mem_in_kb, free_mem_in_kb)
        return results

    @staticmethod
    def get_current_directory():
        return os.getcwd()
