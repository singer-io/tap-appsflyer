from glue_job_libs.base_config import BaseConfig

class TransformConfig(BaseConfig):
    def __init__(self):
        super().__init__()
        self._job_config_json = self.get_job_config_json()

    @property
    def transform_steps(self):
        steps = []
        for step_config_json in self._job_config_json['config']:
            steps.append(TransformStepConfig(step_config_json=step_config_json))

        return steps


class TransformStepConfig:
    def __init__(self, step_config_json: dict) -> None:
        self._step_config_json = step_config_json

    @property
    def step_name(self):
        return self._step_config_json['step_name']

    @property
    def step_type(self):
        return self._step_config_json['step_type']

    @property
    def buffer_size(self):
        return self._step_config_json['step_config']['buffer_size']

    @property
    def rows_in_buffer_limit(self):
        return self._step_config_json['step_config']['rows_in_buffer_limit']

    @property
    def parser_package(self):
        return self._step_config_json['step_config']['parser_package']

    @property
    def parser_class(self):
        return self._step_config_json['step_config']['parser_class']

    @property
    def raw_file_regex(self):
        return self._step_config_json['step_config']['raw_file_regex']

    @property
    def add_timestamp_to_output_file(self):
        return self._step_config_json['step_config']['output']['add_timestamp_to_output_file']

    @property
    def output_file_format(self):
        return self._step_config_json['step_config']['output']['type']

    @property
    def output_file_key_template(self):
        return self._step_config_json['step_config']['output']['file_key']


if __name__ == "__main__":
    print("Begin Test")

    c = TransformConfig()

    print("End Test")