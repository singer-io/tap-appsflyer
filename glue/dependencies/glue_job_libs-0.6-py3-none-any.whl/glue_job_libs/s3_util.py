import boto3
import json


class AWSS3:
    def __init__(self, region='eu-west-1'):
        self.client = boto3.client('s3')

    def delete_s3_file(self, bucket, file):
        response = self.client.delete_object(Bucket=bucket, Key=file)
        return response

    def download_file(self, bucket, file_key, local_file):
        self.client.download_file(bucket, file_key, local_file)

    def get_s3_file(self, bucket, file):
        file_content = self.client.get_object(Bucket=bucket, Key=file)['Body'].read().decode('utf-8')
        return file_content

    def get_json_from_s3(self, bucket: str, file_key: str) -> dict:
        file_object = self.get_s3_file(bucket=bucket, file=file_key)
        json_object = json.loads(file_object)
        return json_object

    def get_s3_file_v2(self, bucket, file):
        file = self.client.get_object(Bucket=bucket, Key=file)
        return file

    def upload_file_to_s3(self, bucket, file_to_upload, file_name_in_bucket):
        result = self.client.upload_file(file_to_upload, bucket, file_name_in_bucket)
        return result

    def upload_json_to_s3(self, bucket, json_object, file_name_in_bucket):
        result = self.client.put_object(
            Body=json.dumps(json_object),
            Bucket=bucket,
            Key=file_name_in_bucket
        )
        return result

    def copy_file_to_other_location(self, source_bucket, source_file_key, destination_bucket, destination_file_key):
        copy_source = {'Bucket': source_bucket, 'Key': source_file_key}
        self.client.copy(copy_source, destination_bucket, destination_file_key)

    def get_all_s3_keys(self, bucket, prefix='', suffix=''):
        """
        Generate the keys in an S3 bucket.

        :param bucket: Name of the S3 bucket.
        :param prefix: Only fetch keys that start with this prefix (optional).
        :param suffix: Only fetch keys that end with this suffix (optional).
        """
        keys = []
        i = 0
        kwargs = {'Bucket': bucket, 'Prefix': prefix}
        while True:
            resp = self.client.list_objects_v2(**kwargs)
            for obj in resp['Contents']:
                key = obj['Key']
                if key.startswith(prefix) and key.endswith(suffix):
                    #yield key
                    keys.append(obj['Key'])
                    i = i + 1
                    # if i > 10:
                    #     break
            try:
                kwargs['ContinuationToken'] = resp['NextContinuationToken']
            except KeyError:
                break
        return keys








