
import json
import collections


class JobConfig:
    def __init__(self, config_json):
        self.config_json = json.loads(config_json)
        config = collections.namedtuple('config', 'bucket, connection, sql_file, output_file, db_server_type')
        self.job_steps = []

        for step in self.config_json["config"]:
            bucket = step["step_config"].get('bucket')
            table =  step["step_config"].get('table')
            connection = step["step_config"].get('connection')
            sql_file = step["step_config"].get('sql_file')
            sql_to_run = step["step_config"].get('sql_to_run')
            output_file = step["step_config"].get('output_file')
            db_server_type = step["step_config"].get('db_server_type')
            step_type = step.get('step_type')
            step_name = step.get('step_name')
            manifest_file = step["step_config"].get('manifest_file')

            buffer_size = step["step_config"].get('buffer_size')
            rows_in_buffer_limit = step["step_config"].get('rows_in_buffer_limit') if step["step_config"].get('rows_in_buffer_limit') else 100000

            if step["step_config"].get("output"):
                if step["step_config"]["output"].get('add_timestamp_to_output_file') == False:
                    add_timestamp_to_output_file = False
                else:
                    add_timestamp_to_output_file = True
            else:
                add_timestamp_to_output_file = True

            parser_package = step["step_config"].get('parser_package')
            parser_class = step["step_config"].get('parser_class')
            raw_file_prefix = step["step_config"].get('raw_file_prefix')

            if step["step_config"].get("output"):
                output_file_key = step["step_config"]["output"].get('file_key')
                output_bucket = step["step_config"]["output"].get('bucket')
            else:
                output_file_key = None
                output_bucket = None

            step_config = {
                "step_name": step_name,
                "step_type": step_type,
                "step_config": {
                    "bucket": bucket,
                    "connection": connection,
                    "sql_file": sql_file,
                    "sql_to_run": sql_to_run,
                    "output_file": output_file,
                    "db_server_type": db_server_type,
                    "table": table,
                    "buffer_size": buffer_size,
                    "rows_in_buffer_limit": rows_in_buffer_limit,
                    "add_timestamp_to_output_file": add_timestamp_to_output_file,
                    "manifest_file": manifest_file,
                    "output_file_key": output_file_key,
                    "output_bucket": output_bucket,
                    "parser_package": parser_package,
                    "parser_class": parser_class,
                    "raw_file_prefix": raw_file_prefix
                }
            }
            self.job_steps.append(step_config)

        #self.job_config = config(bucket, connection, sql_file, output_file, db_server_type)

