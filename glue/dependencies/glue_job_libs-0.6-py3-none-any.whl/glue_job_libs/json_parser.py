

class JSONParser:
    def __init__(self, tables_metadata):
        self.tables_metadata = tables_metadata
        self.root_table_name = self.get_root_table_name()
        self.tables = {self.root_table_name: {"rows": []}}
        self.column_prefix = ''

    def get_root_table_name(self):
        # root table is the first one

        if self.tables_metadata:
            root_table_name = list(self.tables_metadata)[0]
        if not root_table_name:
            raise ValueError \
                ('Root table not found in the table metadata object {}'.format(self.tables_metadata))
        return root_table_name

    @staticmethod
    def new_table_is_needed(obj):
        if isinstance(obj, list) and obj:
            return True
        return False

    def get_table_key_value(self, table_name, obj, current_parend_id):
        key_column = ''
        key = ''
        for k, v in self.tables_metadata.items():
            if k == table_name:
                key_column = v["keys"]
                break

        if isinstance(obj, dict):
            for kk, vv in obj.items():
                if kk == key_column:
                    key = vv
                    break

        if key_column == 'dl_use_parent_id':
            key = current_parend_id

        assert key, ("Table {} not found in the tables_metadata or key not found in the object {} "
                     "in the function get_table_key_value".format(table_name, obj))
        return key

    def get_table_partition_key_value(self, table_name, obj):
        partition = ""
        for k, v in self.tables_metadata.items():
            if k == table_name:
                partition_column = v["partition_column"]

        if isinstance(obj, dict):
            for k, v in obj.items():
                if k == partition_column:
                    partition = v
                    break

        if not partition:
            raise ValueError \
                ('Table {} do not have partition column defined in the tables metadata.'.format(table_name))
        return partition

    def get_parent_record_key(self, table_name, obj, current_parend_id):
        new_parent_id = self.get_table_key_value(table_name, obj, current_parend_id)
        if not new_parent_id:
            raise ValueError \
                ('Table {} do not have key column defined in the tables metadata.'.format(table_name))
        return new_parent_id

    def json_to_tables(self, obj, tables):
        """Recursively fetch values from nested JSON."""

        table_row = {}

        self.tables = tables
        if self.root_table_name not in self.tables.keys():
            self.tables.update({self.root_table_name: {"rows": []}})


        def extract(obj, table_name, column_prefix='', table_row={}, append_row=True, parent_table_name="",
                    parent_id=-1, partition_val=""):
            try:
                if isinstance(obj, dict):

                    if table_name != parent_table_name:
                        new_parent_id = self.get_parent_record_key(table_name=table_name, obj=obj, current_parend_id=parent_id)
                    else:
                        new_parent_id = parent_id

                    # take partition values only from the main table
                    if not parent_table_name:
                        partition_val = self.get_table_partition_key_value(table_name=table_name, obj=obj)

                    for k, v in obj.items():
                        # if value of object is not empty array then create a separate table.
                        if self.new_table_is_needed(obj=v):
                            child_table = k
                            new_table_name = table_name + "__" + child_table
                            if not self.tables.get(new_table_name):
                                self.tables.update({new_table_name: {"rows": []}})
                            for list_obj in v:
                                if list_obj:
                                    new_table_row = {}

                                    if not isinstance(list_obj, dict):
                                        list_obj = {"dl_agc_value": list_obj}

                                    extract(
                                        obj=list_obj,
                                        table_name=new_table_name,
                                        column_prefix='',
                                        table_row=new_table_row,
                                        append_row=True,
                                        parent_table_name=table_name,
                                        parent_id=new_parent_id,
                                        partition_val=partition_val
                                    )
                        else:
                            # collecting columns for one row. if value of object is another object
                            # then recursively fetch values and add as columns with prefix of parent key.
                            if isinstance(v, dict):
                                if len(v) > 0:
                                    new_column_prefix = column_prefix + k + '.'
                                    extract(
                                        obj=v,
                                        table_name=table_name,
                                        column_prefix=new_column_prefix,
                                        table_row=table_row,
                                        append_row=False,
                                        parent_table_name=table_name,
                                        parent_id=new_parent_id,
                                        partition_val=partition_val
                                    )
                                else:
                                    pass
                            else:
                                if isinstance(v, list) and not v:
                                    pass
                                else:
                                    table_row.update({column_prefix + k: str(v)})
                    if append_row:
                        if parent_table_name:
                            table_row.update({parent_table_name + "_key": str(parent_id)})
                        table_row.update({"partition_key_dt": str(partition_val)})
                        table_row.update({table_name + "_key": str(new_parent_id)})
                        self.tables[table_name]["rows"].append(table_row)
            except Exception as e:
                print(e)
                print("Error while extracting values from object: {}".format(obj))
                print("Error while executing extracting with parameters: table_name: {}, column_prefix:{}, "
                      "append_row:{}, parent_table_name:{}, parent_id:{}, partition_val:{}".format(
                    table_name, column_prefix, append_row, parent_table_name, parent_id, partition_val
                ))
                raise

        extract(
            obj=obj,
            table_name=self.root_table_name,
            column_prefix='',
            table_row=table_row,
            append_row=True,
            parent_table_name="",
            parent_id=-1,
            partition_val=""
        )

        return self.tables
